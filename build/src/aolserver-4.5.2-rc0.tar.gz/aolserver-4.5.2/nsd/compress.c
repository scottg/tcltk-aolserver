/*
 * The contents of this file are subject to the AOLserver Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://aolserver.com/.
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is AOLserver Code and related documentation
 * distributed by AOL.
 * 
 * The Initial Developer of the Original Code is America Online,
 * Inc. Portions created by AOL are Copyright (C) 1999 America Online,
 * Inc. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms
 * of the GNU General Public License (the "GPL"), in which case the
 * provisions of GPL are applicable instead of those above.  If you wish
 * to allow use of your version of this file only under the terms of the
 * GPL and not to allow others to use your version of this file under the
 * License, indicate your decision by deleting the provisions above and
 * replace them with the notice and other provisions required by the GPL.
 * If you do not delete the provisions above, a recipient may use your
 * version of this file under either the License or the GPL.
 */

/*
 * compress.c --
 *
 *	Support for loadable gzip compression.
 */

static const char *RCSID = "@(#) $Header: /cvsroot/aolserver/aolserver/nsd/compress.c,v 1.8 2006/06/26 00:28:09 jgdavidson Exp $, compiled: " __DATE__ " " __TIME__;

#include "nsd.h"

static Ns_GzipProc *gzipProcPtr;


/*
 *----------------------------------------------------------------------
 *
 * Ns_Gzip --
 *
 *      Compress a string.
 *
 * Results:
 *      Result of external compress proc, if any, otherwise NS_ERROR.
 *
 * Side effects:
 *      Will write compressed content to given Tcl_DString.
 *
 *----------------------------------------------------------------------
 */

int
Ns_Gzip(char *buf, int len, int level, Tcl_DString *dsPtr)
{
    if (gzipProcPtr != NULL) {
	return (*gzipProcPtr)(buf, len, level, dsPtr);
    }
    return NS_ERROR;
}


/*
 *----------------------------------------------------------------------
 *
 * Ns_SetGzipProc --
 *
 *      Set the global procedure for compression.  Called by the
 *	nszlib module when loaded.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      Later calls to Ns_Gzip will use given function.
 *
 *----------------------------------------------------------------------
 */

void
Ns_SetGzipProc(Ns_GzipProc *procPtr)
{
    gzipProcPtr = procPtr;
}


/*
 *----------------------------------------------------------------------
 *
 * Ns_Compress, Ns_CompressGzip --
 *
 *      AOLserver 4.0 compression routines.
 *
 * Results:
 *      See Ns_Gzip.
 *
 * Side effects:
 *      See Ns_Gzip.
 *
 *----------------------------------------------------------------------
 */

int
Ns_Compress(char *buf, int len, Tcl_DString *outPtr, int level)
{
    return Ns_Gzip(buf, len, level, outPtr);
}

int
Ns_CompressGzip(char *buf, int len, Tcl_DString *outPtr, int level)
{
    return Ns_Gzip(buf, len, level, outPtr);
}
